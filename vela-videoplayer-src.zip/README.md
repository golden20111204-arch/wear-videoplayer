# 手錶影片播放器（Xiaomi Watch S4 + 手機同步端）

手錶端：Vela 快應用「影片播放器」——影片庫、逐幀動畫＋音訊播放、可拖進度條、上下首、±5s、音量。
手機端：Android App「影片同步」——選影片 → 抽幀＋抽音訊 → interconnect 分片傳到手錶空間（`internal://files/vp/`）。

## 重要：手錶上為什麼是「逐幀動畫」而不是真影片

Xiaomi Vela 快應用框架**沒有影片元件/影片 API**（媒體只有 `system.audio` + 圖片 + `image-animator` 逐幀動畫）。
所以本方案的「影片」= 手機端預先把影片渲成 240p 小圖（3~30fps）＋ AAC 音訊，存到 S4 的 32GB 空間，手錶用
`image-animator` 播畫面、`system.audio` 播音，雙引擎同步、可 seek。
這是官方能力內最接近影片的形式；畫面會像慢格/電影感，30fps 檔最接近正常影片。

## 目錄

```
watch-videoplayer/   Vela 快應用（手錶端）
  src/               manifest + 3 頁（index 影片庫 / player 播放 / transfer 同步接收）
  dist/              aiot build 產出的 .debug.rpk
  sign/              簽名 pems（與手機 App 同源）
android/             手機同步端（Kotlin + Gradle，含 XMS Wearable SDK aar）
shared/protocol.md   雙端同步協議（chunk 格式、目錄結構、錯誤處理）
```

## 一、簽名配對（interconnect 硬性要求）

手錶快應用與手機 App 必須**同包名（`com.wear.videoplayer`）＋同簽名**。
簽名材料已在倉庫裡（雙端共用一把金鑰）：

- 手機端：`android/keystore/videoplayer.p12`（密碼 `wearvideo123`，alias `videoplayer`）
  已寫入 `android/app/build.gradle` 的 signingConfigs（debug 與 release 都用它）。
- 手錶端：`watch-videoplayer/sign/{debug,release}/{private,certificate}.pem`

要換自己的金鑰：`sh android/tools/make-sign-pem.sh`（重產 p12 + pems），
然後雙端重新打包、手錶端先 uninstall 舊包再裝新包。

## 二、手錶端（watch-videoplayer）

1. 環境：AIoT-IDE（或本機 node + aiot-toolkit），依賴裝法見 `watch-videoplayer/.npmrc`（npmmirror）。
2. 建置：
   ```
   cd watch-videoplayer
   npm i
   npx aiot build     # → dist/com.wear.videoplayer.debug.1.0.0.rpk
   ```
3. 裝到 S4：AIoT-IDE 開專案 → 選 S4 設備（adb 連線）→ 調試（會自動裝 rpk）；
   或手動把 rpk 裝到 S4。
4. 手錶端頁面：
   - **影片庫**：已同步影片列表（封面/時長/fps），點開播放；「✕」連按兩下刪除；「＋ 從手機同步」進同步頁。
   - **同步頁**：顯示與手機端連線狀態、傳輸進度；**同步進行中請保持此頁開啟**（手機端會自動幫它打開）。
   - **播放頁**：逐幀動畫＋音訊；控制列＝上／-5s／播・停／+5s／下，音量 VOL±；
     進度條可拖（放開即 seek，畫面與音訊同步跳）。播完自動下一首。

## 三、手機端（android）

環境：JDK 17 + Android Studio（或 command-line gradle），Android SDK 34。
`app/libs/xms-wearable-lib_1.4_release.aar` 為小米穿戴 XMS Wearable SDK（官方 interconnect demo 附）。

```
cd android
./gradlew :app:assembleDebug      # 或 Android Studio 開 android/ 後 Run
```

產出的 APK 用**同一把 p12 簽名**（build.gradle 已配好），裝到與 S4 配對的手機上。

功能：
- **選影片**：系統圖片選擇器（video），可一次選多支。
- **壓縮預設檔**（頁面上方切）：省空間(3fps)/標準(10fps)/順暢(30fps)/高清(320p)。
- **同步到手錶**：抽幀＋封面＋音訊(AAC 單聲道) → 分片傳到手錶空間，進度頁可看、可取消。
- **手錶端刪除 / 移除記錄**：同步狀態回寫本地影片庫（Room）。

前置：
- 手機已裝「小米穿戴」或「小米運動健康」App 並已與 S4 配對（XMS SDK 經宿主 App 通訊，`<queries>` 已声明）。
- 首次同步會彈穿戴權限授權（DEVICE_MANAGER / NOTIFY）。

## 四、容量與時間估算（S4 32GB）

| 預設檔 | 每分鐘影片約 | 可存 | BLE 傳輸約 |
|---|---|---|---|
| 省空間 3fps | 1.5 MB | ~140 小時 | 1 分 |
| 標準 10fps | 5 MB | ~55 小時 | 4 分 |
| 順暢 30fps | 14 MB | ~20 小時 | 10 分 |
| 高清 10fps 320p | 10 MB | ~28 小時 | 6 分 |

## 五、已知限制

- 無倍速（Vela audio 無 rate API），快放 = ±5s 跳轉。
- 30fps 檔：每幀 Flash 讀檔＋JPEG 解碼的負載 S4 實測前未知；不順就改用標準檔。
- 音訊為 AAC(m4a)；若 S4 解不了，後續可在手機端改編 MP3（minimp3）再同步。
- 傳輸走 BLE，長影片耗時以「分」計，同步中雙端勿關 App、手錶別離開。
- 單支影片 ≤ 1800 幀（超出自動降 fps）；無音訊影片可播純幀動畫。
