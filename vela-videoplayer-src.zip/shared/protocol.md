# 同步協議 v1（手錶端 ↔ 手機端）

雙端共用的消息協議。每一條 `system.interconnect` 訊息 = 一個 **UTF-8 JSON 字串**。
- 手機端：`MessageApi.sendMessage(nodeId, json.toByteArray(UTF_8))`
- 手錶端：`connect.onmessage = (res) => transfer.handle(res.data, cbs)`

## 常量

| 項目 | 值 | 說明 |
|---|---|---|
| 分片大小 | base64 16000 字元（= 12000 位元組） | 每 chunk 訊息的 `b64` 上限；16000 是 4 的倍數，可獨立解碼 |
| 手錶端根目錄 | `internal://files/vp/` | 手錶空間（S4 32GB），持久化 |
| 單支影片幀數上限 | 1800 | 超過時手機端自動降 fps |
| 幀檔案命名 | `f/%06d.jpg`（0 起，連號無空缺） | 缺幀用前一幀補，保證 0..N-1 完整 |

## 每支影片的手錶端目錄

```
internal://files/vp/
  library.json              # 影片庫清單（手錶端維護）
  <id>/
    meta.json               # 手錶端在 done 時寫入
    cover.jpg               # 封面 240/320×240/320 JPEG
    audio.m4a               # AAC-LC 單聲道（可能沒有）
    f/000000.jpg ... 00NNNN.jpg
```

## 訊息

### 1. video（傳輸開始，每個文件清單一個）

```json
{
  "v": 1, "t": "video",
  "id": "abc",
  "title": "我的影片",
  "duration": 60,
  "fps": 10,
  "frames": 600,
  "w": 240, "h": 240,
  "hasAudio": true,
  "totalBytes": 12345678,
  "added": 1700000000000
}
```

手錶端動作：`rmdir internal://files/vp/<id>`（重傳時清舊）→ `mkdir <id>/f/` → 建立接收狀態。

### 2. chunk（資料分片，按順序發）

```json
{ "v": 1, "t": "chunk", "id": "abc", "file": "f", "seq": 12, "b64": "...." }
```

- `file`: `"cover"` | `"audio"` | `"f"`
- `seq`：
  - `cover` / `audio`：分片序號 0,1,2…
  - `f`：`幀號*2 + 分片(0/1)`（單幀 ≤ 24KB → 最多 2 片）
- 手錶端動作：base64 解碼 → `file.writeArrayBuffer({uri, buffer, append:true})`；目標路徑：
  - `cover` → `<id>/cover.jpg`
  - `audio` → `<id>/audio.m4a`
  - `f` → `<id>/f/%06d.jpg`（幀號 = floor(seq/2)）

### 3. done（該影片全部 chunk 送完）

```json
{ "v": 1, "t": "done", "id": "abc" }
```

手錶端動作：寫 `meta.json`（= video 訊息的欄位 + cover 路徑）→ 更新 `library.json` → 提示完成。

### 4. del（從手錶刪除）

```json
{ "v": 1, "t": "del", "id": "abc" }
```

手錶端動作：`rmdir <id>`（recursive）+ 從 `library.json` 移除。

### 5. cancel（傳輸中斷）

```json
{ "v": 1, "t": "cancel", "id": "abc" }
```

手錶端動作：刪掉傳到一半的 `<id>` 目錄。

## 壓縮預設（手機端 Presets）

| 預設檔 | fps | 幀大小 | JPEG q | 音訊 | 約每分鐘影片 | BLE 傳輸約 |
|---|---|---|---|---|---|---|
| 省空間 save | 3 | 240×240 | 40 | AAC 64k 單聲道 | ~1.5 MB | ~1 分 |
| 標準 standard（預設） | 10 | 240×240 | 45 | AAC 96k 單聲道 | ~5 MB | ~4 分 |
| 順暢 fluid | 30 | 240×240 | 45 | AAC 96k 單聲道 | ~14 MB | ~10 分 |
| 高清 hd | 10 | 320×320 | 55 | AAC 96k 單聲道 | ~10 MB | ~6 分 |

- 長影片（> 1800/fps 秒）自動降 fps，幀數固定 1800。
- S4 32GB：標準檔約可存 50+ 小時。

## 錯誤處理

- 手錶端 `writeArrayBuffer` 失敗：記 log、跳過該片（進度會卡住），done 時影片仍可播（缺幀處會卡）；重傳該影片可整段清舊重建。
- 連線中斷（onclose）：手錶端顯示斷線；手機端 Task 失敗 → 顯示「手錶未連線」，重試即可（重試 = 重發 video 訊息，會清舊目錄）。
- `diagnosis` 錯誤碼：`0` OK / `204` 超時 / `1001` 手機端 App 未安裝或簽名不符 / `1000` 其他。
